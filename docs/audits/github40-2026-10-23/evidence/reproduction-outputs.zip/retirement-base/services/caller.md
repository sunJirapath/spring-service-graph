---
service: caller
repo: caller
path: .
exposes: 1
calls: 1
publishes: 0
consumes: 0
tables: 0
findings: 0
---

# caller

Repo `caller`, module `.`.

## Exposes

| Method | Path | Called by | Reaches | Source | Confidence | Evidence |
|---|---|---|---|---|---|---|
| GET | `/entry` | - | `orders GET /orders` | controller | EXACT | [caller/src/main/java/demo/App.java:2](../../../../docs/audits/github40-2026-10-23/fixtures/retirement/base/caller/src/main/java/demo/App.java#L2) |

## Calls

| Target | Method | Path | Client | Matched | Confidence | Evidence |
|---|---|---|---|---|---|---|
| orders | GET | `/orders` | rest-template | `GET /orders` | EXACT | [caller/src/main/java/demo/App.java:2](../../../../docs/audits/github40-2026-10-23/fixtures/retirement/base/caller/src/main/java/demo/App.java#L2) |

## Publishes

_None._

## Consumes

_None._

## Data

_None._

## Findings

_None._
