# Fleet overview

2 services, 2 endpoints, 0 topics, 0 tables, 0 findings.

## Services

| Service | Repo | Module | Exposes | Calls | Publishes | Consumes | Findings |
|---|---|---|---|---|---|---|---|
| [caller](services/caller.md) | caller | `.` | 1 | 1 | 0 | 0 | 0 |
| [orders](services/orders.md) | orders | `.` | 1 | 0 | 0 | 0 | 0 |

## Service dependencies

| From → To | Clients |
|---|---|
| caller → orders | rest-template |

## Topics

_None._

## Findings

_None._

