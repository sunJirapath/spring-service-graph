# Fleet overview

1 services, 0 endpoints, 0 topics, 0 tables, 1 findings.

## Services

| Service | Repo | Module | Exposes | Calls | Publishes | Consumes | Findings |
|---|---|---|---|---|---|---|---|
| [mongo-unannotated-repro](services/mongo-unannotated-repro.md) | mongo-default | `.` | 0 | 0 | 0 | 0 | 1 |

## Service dependencies

_None._

## Topics

_None._

## Findings

| Kind | Count |
|---|---|
| UNRESOLVED | 1 |

- **UNRESOLVED** `mongo-unannotated-repro`: repository CustomerRepository: entity Customer not found in sources — [mongo-default/src/main/java/demo/App.java:4](../../../docs/audits/github40-2026-10-23/fixtures/mongo-default/src/main/java/demo/App.java#L4)
