---
service: mongo-unannotated-repro
repo: mongo-default
path: .
exposes: 0
calls: 0
publishes: 0
consumes: 0
tables: 0
findings: 1
---

# mongo-unannotated-repro

Repo `mongo-default`, module `.`.

## Exposes

_None._

## Calls

_None._

## Publishes

_None._

## Consumes

_None._

## Data

_None._

## Findings

- **UNRESOLVED** repository CustomerRepository: entity Customer not found in sources — [mongo-default/src/main/java/demo/App.java:4](../../../../docs/audits/github40-2026-10-23/fixtures/mongo-default/src/main/java/demo/App.java#L4)
