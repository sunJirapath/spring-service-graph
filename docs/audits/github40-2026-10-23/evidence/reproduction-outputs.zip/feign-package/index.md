# Fleet overview

2 services, 1 endpoints, 0 topics, 0 tables, 0 findings.

## Services

| Service | Repo | Module | Exposes | Calls | Publishes | Consumes | Findings |
|---|---|---|---|---|---|---|---|
| [client-app](services/client-app.md) | feign-package | `client-app` | 0 | 0 | 0 | 0 | 0 |
| [users](services/users.md) | feign-package | `users-app` | 1 | 0 | 0 | 0 | 0 |

## Service dependencies

_None._

## Topics

_None._

## Findings

_None._

