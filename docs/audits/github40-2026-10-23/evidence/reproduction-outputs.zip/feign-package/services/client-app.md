---
service: client-app
repo: feign-package
path: client-app
exposes: 0
calls: 0
publishes: 0
consumes: 0
tables: 0
findings: 0
---

# client-app

Repo `feign-package`, module `client-app`.

## Exposes

_None._

## Calls

_None._

## Publishes

_None._

## Consumes

_None._

## Data

_None._

## Findings

_None._
