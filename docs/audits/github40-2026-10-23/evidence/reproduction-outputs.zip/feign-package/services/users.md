---
service: users
repo: feign-package
path: users-app
exposes: 1
calls: 0
publishes: 0
consumes: 0
tables: 0
findings: 0
---

# users

Repo `feign-package`, module `users-app`.

## Exposes

| Method | Path | Called by | Reaches | Source | Confidence | Evidence |
|---|---|---|---|---|---|---|
| GET | `/users/{id}` | - | - | controller | EXACT | [feign-package/users-app/src/main/java/users/App.java:1](../../../../docs/audits/github40-2026-10-23/fixtures/feign-package/users-app/src/main/java/users/App.java#L1) |

## Calls

_None._

## Publishes

_None._

## Consumes

_None._

## Data

_None._

## Findings

_None._
