---
service: elasticsearch-index-repro
repo: elasticsearch-index
path: .
exposes: 0
calls: 0
publishes: 0
consumes: 0
tables: 1
findings: 0
---

# elasticsearch-index-repro

Repo `elasticsearch-index`, module `.`.

## Exposes

_None._

## Calls

_None._

## Publishes

_None._

## Consumes

_None._

## Data

| Table | Store | Relation | Confidence | Evidence |
|---|---|---|---|---|
| `product` | elasticsearch | uses | EXACT | [elasticsearch-index/src/main/java/demo/App.java:5](../../../../docs/audits/github40-2026-10-23/fixtures/elasticsearch-index/src/main/java/demo/App.java#L5)<br>[elasticsearch-index/src/main/java/demo/App.java:6](../../../../docs/audits/github40-2026-10-23/fixtures/elasticsearch-index/src/main/java/demo/App.java#L6) |

## Findings

_None._
