# Impact report

| | Base | Head |
|---|---|---|
| services | 2 | 2 |
| endpoints | 2 | 1 |
| topics | 0 | 0 |
| tables | 0 | 0 |
| externals | 0 | 0 |
| edges | 4 | 1 |
| findings | 0 | 0 |

## Breaking changes

- Removed `orders GET /orders` is still called by caller

## Endpoints removed

- `orders GET /orders` — called by caller

## Calls removed

- service `caller` **calls** `orders GET /orders` (client=rest-template, method=GET, path=/orders) `EXACT` — `caller/src/main/java/demo/App.java:2`

## Reach removed

- `caller GET /entry` **reaches** `orders GET /orders` `RESOLVED` — `caller/src/main/java/demo/App.java:2`

