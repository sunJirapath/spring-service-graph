---
service: same
repo: beta
path: .
exposes: 0
calls: 0
publishes: 0
consumes: 0
tables: 0
findings: 1
---

# same

Repo `beta`, module `.`.

## Exposes

_None._

## Calls

_None._

## Publishes

_None._

## Consumes

_None._

## Data

_None._

## Findings

- **DUPLICATE_SERVICE** service name 'same' is used by alpha/. and beta/. — [beta/.:1](../../../../docs/audits/github40-2026-10-23/fixtures/duplicate-evidence/beta#L1)
