# Fleet overview

1 services, 0 endpoints, 0 topics, 0 tables, 1 findings.

## Services

| Service | Repo | Module | Exposes | Calls | Publishes | Consumes | Findings |
|---|---|---|---|---|---|---|---|
| [same](services/same.md) | beta | `.` | 0 | 0 | 0 | 0 | 1 |

## Service dependencies

_None._

## Topics

_None._

## Findings

| Kind | Count |
|---|---|
| DUPLICATE_SERVICE | 1 |

- **DUPLICATE_SERVICE** `same`: service name 'same' is used by alpha/. and beta/. — [beta/.:1](../../../docs/audits/github40-2026-10-23/fixtures/duplicate-evidence/beta#L1)
