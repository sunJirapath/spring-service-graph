---
service: rabbit-overload-repro
repo: rabbit-overload
path: .
exposes: 0
calls: 0
publishes: 1
consumes: 0
tables: 0
findings: 0
---

# rabbit-overload-repro

Repo `rabbit-overload`, module `.`.

## Exposes

_None._

## Calls

_None._

## Publishes

| Topic | Consumers | Via | Confidence | Evidence |
|---|---|---|---|---|
| `payload` | - | RabbitTemplate | EXACT | [rabbit-overload/src/main/java/demo/App.java:9](../../../../docs/audits/github40-2026-10-23/fixtures/rabbit-overload/src/main/java/demo/App.java#L9) |

## Consumes

_None._

## Data

_None._

## Findings

_None._
