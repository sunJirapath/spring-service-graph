# Fleet overview

1 services, 0 endpoints, 0 topics, 0 tables, 0 findings.

## Services

| Service | Repo | Module | Exposes | Calls | Publishes | Consumes | Findings |
|---|---|---|---|---|---|---|---|
| [openapi-framework-prefix](services/openapi-framework-prefix.md) | openapi-framework-prefix | `.` | 0 | 0 | 0 | 0 | 0 |

## Service dependencies

_None._

## Topics

_None._

## Findings

_None._

