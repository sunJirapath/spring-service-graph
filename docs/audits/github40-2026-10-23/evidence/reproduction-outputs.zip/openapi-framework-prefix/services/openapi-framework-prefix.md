---
service: openapi-framework-prefix
repo: openapi-framework-prefix
path: .
exposes: 0
calls: 0
publishes: 0
consumes: 0
tables: 0
findings: 0
---

# openapi-framework-prefix

Repo `openapi-framework-prefix`, module `.`.

## Exposes

_None._

## Calls

_None._

## Publishes

_None._

## Consumes

_None._

## Data

_None._

## Findings

_None._
