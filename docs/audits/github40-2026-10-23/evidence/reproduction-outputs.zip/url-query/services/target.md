---
service: target
repo: target
path: .
exposes: 1
calls: 0
publishes: 0
consumes: 0
tables: 0
findings: 0
---

# target

Repo `target`, module `.`.

## Exposes

| Method | Path | Called by | Reaches | Source | Confidence | Evidence |
|---|---|---|---|---|---|---|
| GET | `/` | - | - | controller | EXACT | [target/src/main/java/demo/Controller.java:1](../../../../docs/audits/github40-2026-10-23/fixtures/url-query/target/src/main/java/demo/Controller.java#L1) |

## Calls

_None._

## Publishes

_None._

## Consumes

_None._

## Data

_None._

## Findings

_None._
