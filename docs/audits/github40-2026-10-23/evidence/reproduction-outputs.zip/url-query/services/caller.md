---
service: caller
repo: caller
path: .
exposes: 0
calls: 1
publishes: 0
consumes: 0
tables: 0
findings: 0
---

# caller

Repo `caller`, module `.`.

## Exposes

_None._

## Calls

| Target | Method | Path | Client | Matched | Confidence | Evidence |
|---|---|---|---|---|---|---|
| target?x=1 | GET | `/` | rest-template | - | EXACT | [caller/src/main/java/demo/Call.java:1](../../../../docs/audits/github40-2026-10-23/fixtures/url-query/caller/src/main/java/demo/Call.java#L1) |

## Publishes

_None._

## Consumes

_None._

## Data

_None._

## Findings

_None._
