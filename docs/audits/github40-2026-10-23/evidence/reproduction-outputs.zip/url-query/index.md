# Fleet overview

2 services, 1 endpoints, 0 topics, 0 tables, 0 findings.

## Services

| Service | Repo | Module | Exposes | Calls | Publishes | Consumes | Findings |
|---|---|---|---|---|---|---|---|
| [caller](services/caller.md) | caller | `.` | 0 | 1 | 0 | 0 | 0 |
| [target](services/target.md) | target | `.` | 1 | 0 | 0 | 0 | 0 |

## Service dependencies

| From → To | Clients |
|---|---|
| caller → target?x=1 | rest-template |

## Topics

_None._

## Findings

_None._

