---
service: openapi-framework-prefix
repo: openapi-framework-prefix
path: .
exposes: 1
calls: 0
publishes: 0
consumes: 0
tables: 0
findings: 0
---

# openapi-framework-prefix

Repo `openapi-framework-prefix`, module `.`.

## Exposes

| Method | Path | Called by | Reaches | Source | Confidence | Evidence |
|---|---|---|---|---|---|---|
| GET | `/petclinic/api/owners` | - | - | openapi | RESOLVED | [openapi-framework-prefix/src/main/resources/openapi.yml:9](../../controls/openapi-framework-prefix/src/main/resources/openapi.yml#L9)<br>[openapi-framework-prefix/src/main/resources/application.properties:1](../../controls/openapi-framework-prefix/src/main/resources/application.properties#L1) |

## Calls

_None._

## Publishes

_None._

## Consumes

_None._

## Data

_None._

## Findings

_None._
